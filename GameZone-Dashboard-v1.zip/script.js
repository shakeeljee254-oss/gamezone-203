// GameZone dashboard interactions — all JavaScript lives in this file
"use strict";

const searchInput = document.getElementById("gameSearch");
const gameCards = Array.from(document.querySelectorAll(".game-card"));
const categoryButtons = Array.from(document.querySelectorAll(".category-chip"));
const emptyState = document.getElementById("emptyState");
const gameGrid = document.getElementById("gameGrid");
const menuToggle = document.getElementById("menuToggle");
const sidebar = document.getElementById("sidebar");

let activeCategory = "all";

function filterGames() {
  const searchTerm = (searchInput?.value || "").trim().toLowerCase();
  let visibleCount = 0;

  gameCards.forEach((card) => {
    const name = (card.dataset.name || "").toLowerCase();
    const category = (card.dataset.category || "").toLowerCase();
    const matchesSearch = name.includes(searchTerm);
    const matchesCategory = activeCategory === "all" || category === activeCategory;
    const isVisible = matchesSearch && matchesCategory;

    card.hidden = !isVisible;
    if (isVisible) visibleCount += 1;
  });

  emptyState.hidden = visibleCount !== 0;
  gameGrid.setAttribute("aria-label", `${visibleCount} games shown`);
}

searchInput?.addEventListener("input", filterGames);

categoryButtons.forEach((button) => {
  button.addEventListener("click", () => {
    activeCategory = button.dataset.category || "all";
    categoryButtons.forEach((item) => {
      const selected = item === button;
      item.classList.toggle("selected", selected);
      item.setAttribute("aria-pressed", String(selected));
    });
    filterGames();
  });
});

menuToggle?.addEventListener("click", () => {
  const isOpen = sidebar.classList.toggle("open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
});

document.addEventListener("click", (event) => {
  if (!sidebar || !menuToggle || window.innerWidth > 760) return;
  const clickedInsideSidebar = sidebar.contains(event.target);
  const clickedMenu = menuToggle.contains(event.target);
  if (!clickedInsideSidebar && !clickedMenu) {
    sidebar.classList.remove("open");
    menuToggle.setAttribute("aria-expanded", "false");
  }
});

// Close the mobile navigation after choosing a section.
document.querySelectorAll(".side-nav a").forEach((link) => {
  link.addEventListener("click", () => {
    sidebar?.classList.remove("open");
    menuToggle?.setAttribute("aria-expanded", "false");
  });
});

// Update the visible playable-game count from cards marked as available.
const playableCount = gameCards.filter((card) => card.querySelector(".card-play")).length;
const gameCount = document.getElementById("gameCount");
const libraryCount = document.getElementById("libraryCount");
if (gameCount) gameCount.textContent = String(playableCount).padStart(2, "0");
if (libraryCount) libraryCount.textContent = `${playableCount} GAME${playableCount === 1 ? "" : "S"}`;

filterGames();
